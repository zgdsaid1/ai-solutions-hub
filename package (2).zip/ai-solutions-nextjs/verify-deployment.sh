#!/bin/bash

# AI Solutions Hub - Deployment Verification Script
# Run this after successful Vercel deployment

echo "🔍 Verifying AI Solutions Hub deployment..."
echo "Target URL: https://aisolutionshub.co"
echo ""

# Test homepage
echo "🏠 Testing homepage..."
curl -s -o /dev/null -w "%{http_code}" https://aisolutionshub.co

if [ $? -eq 0 ]; then
    echo " ✅ Homepage accessible"
else
    echo " ❌ Homepage not accessible"
fi

echo ""
echo "🛠️  Testing dashboard..."
curl -s -o /dev/null -w "%{http_code}" https://aisolutionshub.co/dashboard

if [ $? -eq 0 ]; then
    echo " ✅ Dashboard accessible"
else
    echo " ❌ Dashboard not accessible"
fi

echo ""
echo "🧪 Testing AI tools endpoints..."

# Test a few AI tool endpoints
tools=("ai-marketing-generator" "ai-data-analytics" "ai-inventory-tracker")

for tool in "${tools[@]}"; do
    echo "Testing $tool..."
    response=$(curl -s -X POST https://bqvcpbdwjkmbjsynhuqz.supabase.co/functions/v1/$tool \
        -H "Content-Type: application/json" \
        -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJxdmNwYmR3amttYmpzeW5odXF6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjIyMzg5NzksImV4cCI6MjA3NzgxNDk3OX0.1Ze3wURXgaZDC8bgLVBVq0UU8ZRMFtBJkm1Od2zTet0" \
        -d '{"query":"test"}' \
        -w "%{http_code}")
    
    if [[ $response == *"200"* ]]; then
        echo " ✅ $tool endpoint working"
    else
        echo " ❌ $tool endpoint issue"
    fi
done

echo ""
echo "🌐 Custom domain tests..."
curl -s -o /dev/null -w "%{http_code}" https://www.aisolutionshub.co

if [ $? -eq 0 ]; then
    echo " ✅ www subdomain working"
else
    echo " ❌ www subdomain not working"
fi

echo ""
echo "🔒 SSL certificate check..."
cert_status=$(curl -s -I https://aisolutionshub.co | grep -i "HTTP/2" | wc -l)

if [ $cert_status -gt 0 ]; then
    echo " ✅ SSL certificate active"
else
    echo " ❌ SSL certificate issue"
fi

echo ""
echo "📊 Deployment verification complete!"
echo ""
echo "🎯 Next steps if all tests pass:"
echo "1. Task 20: Deploy backend to Railway"
echo "2. Task 21: Configure Stripe webhooks"
echo "3. Task 22: Comprehensive testing"
echo "4. Task 23: Production launch"
