#!/bin/bash

# AI Solutions Hub - Quick Local Testing Setup
echo "🚀 Setting up AI Solutions Hub for local testing..."

# Check if we're in the right directory
if [ ! -f "package.json" ]; then
    echo "❌ Error: package.json not found. Please run this script from the ai-solutions-nextjs directory."
    exit 1
fi

# Install dependencies
echo "📦 Installing dependencies..."
if command -v pnpm &> /dev/null; then
    pnpm install
else
    echo "⚠️  pnpm not found, using npm..."
    npm install
fi

# Copy environment file if it doesn't exist
if [ ! -f ".env.local" ]; then
    echo "📝 Creating .env.local from template..."
    cp .env.local.example .env.local
    echo "✅ Environment file created. Please check .env.local has the correct values."
else
    echo "✅ .env.local already exists"
fi

# Clear any existing build cache
echo "🧹 Clearing build cache..."
rm -rf .next
rm -rf node_modules/.cache

# Start development server
echo "🌟 Starting development server..."
echo "Access the application at: http://localhost:3000"
echo "Dashboard available at: http://localhost:3000/dashboard"
echo ""
echo "Available AI Tools to test:"
echo "  1. Marketing Content Generator"
echo "  2. Legal Document Drafting" 
echo "  3. Data Analytics"
echo "  4. Email Marketing"
echo "  5. Document Summarization"
echo "  6. Customer Support Assistant"
echo "  7. Sales Analytics"
echo "  8. Content Creation"
echo "  9. AI Smart Inventory Tracker"
echo " 10. AI Logistics & Route Optimizer"
echo ""
echo "Press Ctrl+C to stop the server"
echo "=================================="

if command -v pnpm &> /dev/null; then
    pnpm dev
else
    npm run dev
fi
