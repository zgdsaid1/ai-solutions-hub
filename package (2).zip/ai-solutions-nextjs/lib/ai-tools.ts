import { supabase } from './supabase'

export interface AIToolRequest {
  toolId: string
  prompt: string
  context?: Record<string, any>
}

export interface AIToolResponse {
  success: boolean
  data?: any
  error?: string
}

export async function callAITool(endpoint: string, request: AIToolRequest): Promise<AIToolResponse> {
  try {
    const { data: { session } } = await supabase.auth.getSession()
    
    if (!session) {
      return { success: false, error: 'Authentication required' }
    }

    const response = await fetch(
      `${process.env.NEXT_PUBLIC_SUPABASE_URL}/functions/v1/${endpoint}`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`,
        },
        body: JSON.stringify(request),
      }
    )

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}))
      return {
        success: false,
        error: errorData.error || `Request failed with status ${response.status}`
      }
    }

    const data = await response.json()
    return { success: true, data }
  } catch (error) {
    console.error('AI Tool Error:', error)
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error occurred'
    }
  }
}
