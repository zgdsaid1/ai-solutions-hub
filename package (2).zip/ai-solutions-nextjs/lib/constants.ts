export const AI_TOOLS = [
  {
    id: 'marketing',
    name: 'AI Marketing Strategist',
    description: 'Generate comprehensive marketing strategies, campaign ideas, and growth plans for your business',
    icon: 'TrendingUp',
    endpoint: 'ai-marketing-strategist',
    category: 'Business Growth',
    features: ['Campaign Planning', 'Market Analysis', 'Content Strategy', 'Growth Tactics']
  },
  {
    id: 'legal',
    name: 'AI Legal Advisor',
    description: 'Get legal guidance, contract reviews, and compliance advice for your business needs',
    icon: 'Scale',
    endpoint: 'ai-legal-advisor',
    category: 'Legal & Compliance',
    features: ['Contract Review', 'Compliance Guidance', 'Legal Research', 'Document Drafting']
  },
  {
    id: 'data',
    name: 'AI Data Analyzer',
    description: 'Analyze data, generate insights, and create visualizations from your business metrics',
    icon: 'BarChart3',
    endpoint: 'ai-data-analyzer',
    category: 'Analytics',
    features: ['Data Analysis', 'Trend Detection', 'Predictive Insights', 'Report Generation']
  },
  {
    id: 'email',
    name: 'AI Email Assistant',
    description: 'Compose professional emails, manage correspondence, and automate email workflows',
    icon: 'Mail',
    endpoint: 'ai-email-assistant',
    category: 'Communication',
    features: ['Email Drafting', 'Template Creation', 'Response Automation', 'Follow-up Management']
  },
  {
    id: 'document',
    name: 'AI Document Automation',
    description: 'Generate, format, and automate document creation for contracts, reports, and proposals',
    icon: 'FileText',
    endpoint: 'ai-document-automation',
    category: 'Documentation',
    features: ['Document Generation', 'Template Management', 'Format Conversion', 'Auto-filling']
  },
  {
    id: 'support',
    name: 'AI Customer Support',
    description: 'Provide 24/7 customer support, answer queries, and resolve issues automatically',
    icon: 'Headphones',
    endpoint: 'ai-customer-support',
    category: 'Customer Service',
    features: ['Query Resolution', 'Knowledge Base', 'Ticket Management', 'Response Templates']
  },
  {
    id: 'sales',
    name: 'AI Sales Assistant',
    description: 'Generate sales pitches, qualify leads, and automate sales processes',
    icon: 'DollarSign',
    endpoint: 'ai-sales-assistant',
    category: 'Sales',
    features: ['Lead Qualification', 'Pitch Generation', 'Follow-up Automation', 'Deal Tracking']
  },
  {
    id: 'content',
    name: 'AI Content Creator',
    description: 'Create engaging content for blogs, social media, and marketing materials',
    icon: 'Pen',
    endpoint: 'ai-content-creator',
    category: 'Content',
    features: ['Blog Writing', 'Social Media Posts', 'SEO Optimization', 'Content Calendar']
  },
  {
    id: 'inventory',
    name: 'AI Smart Inventory Tracker',
    description: 'Monitor stock levels, predict demand, and automate inventory management with SMS alerts',
    icon: 'Package',
    endpoint: 'ai-inventory-tracker',
    category: 'Operations',
    features: ['Stock Monitoring', 'Demand Prediction', 'SMS Alerts', 'Analytics']
  },
  {
    id: 'logistics',
    name: 'AI Logistics & Route Optimizer',
    description: 'Optimize delivery routes, track shipments, and streamline logistics operations',
    icon: 'Truck',
    endpoint: 'ai-logistics-optimizer',
    category: 'Operations',
    features: ['Route Optimization', 'Delivery Tracking', 'Real-time Updates', 'Performance Analytics']
  }
]

export const PRICING_PLANS = [
  {
    id: 'basic',
    name: 'Basic',
    price: 9,
    interval: 'month',
    features: [
      '2 AI Tools Access',
      '100 Requests/month',
      'Email Support',
      'Basic Analytics'
    ],
    stripePriceId: process.env.NEXT_PUBLIC_STRIPE_BASIC_PRICE_ID
  },
  {
    id: 'pro',
    name: 'Pro',
    price: 29,
    interval: 'month',
    popular: true,
    features: [
      'All 8 AI Tools',
      '1,000 Requests/month',
      'Priority Support',
      'Advanced Analytics',
      'API Access',
      'Custom Integrations'
    ],
    stripePriceId: process.env.NEXT_PUBLIC_STRIPE_PRO_PRICE_ID
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    price: 99,
    interval: 'month',
    features: [
      'Unlimited AI Tools',
      '10,000 Requests/month',
      '24/7 Priority Support',
      'Advanced Analytics & Reports',
      'Dedicated Account Manager',
      'Custom Training',
      'SLA Guarantee',
      'White-label Options'
    ],
    stripePriceId: process.env.NEXT_PUBLIC_STRIPE_ENTERPRISE_PRICE_ID
  },
  {
    id: 'license',
    name: 'License',
    price: 299,
    interval: 'month',
    features: [
      'Complete Platform License',
      'Unlimited Everything',
      'Full Source Code Access',
      'Self-hosting Option',
      '24/7 Premium Support',
      'Customization Services',
      'Training & Onboarding',
      'Lifetime Updates'
    ],
    stripePriceId: process.env.NEXT_PUBLIC_STRIPE_LICENSE_PRICE_ID
  }
]
