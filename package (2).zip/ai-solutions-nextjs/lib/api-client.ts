// Frontend Helper Functions for Railway Backend Integration
// Add these to your Next.js app/lib directory

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'https://your-railway-app.up.railway.app';

class ApiClient {
  private baseURL: string;
  private token: string | null = null;

  constructor(baseURL: string) {
    this.baseURL = baseURL;
  }

  // Get authentication token from localStorage
  private getToken(): string | null {
    if (typeof window !== 'undefined') {
      const token = localStorage.getItem('auth_token');
      this.token = token;
      return token;
    }
    return null;
  }

  // Set authentication token
  setToken(token: string) {
    this.token = token;
    if (typeof window !== 'undefined') {
      localStorage.setItem('auth_token', token);
    }
  }

  // Clear authentication token
  clearToken() {
    this.token = null;
    if (typeof window !== 'undefined') {
      localStorage.removeItem('auth_token');
    }
  }

  // Make API request with authentication
  private async request<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<T> {
    const token = this.getToken();
    const headers: HeadersInit = {
      'Content-Type': 'application/json',
      ...options.headers,
    };

    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    const response = await fetch(`${this.baseURL}/api${endpoint}`, {
      ...options,
      headers,
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
    }

    return response.json();
  }

  // ==================== AUTHENTICATION METHODS ====================

  // User signup
  async signup(email: string, password: string, fullName: string) {
    const response = await this.request<{
      success: boolean;
      message: string;
      data: { user: any; token: string };
    }>('/auth/signup', {
      method: 'POST',
      body: JSON.stringify({ email, password, fullName }),
    });

    if (response.success) {
      this.setToken(response.data.token);
    }

    return response;
  }

  // User signin
  async signin(email: string, password: string) {
    const response = await this.request<{
      success: boolean;
      message: string;
      data: { user: any; token: string };
    }>('/auth/signin', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });

    if (response.success) {
      this.setToken(response.data.token);
    }

    return response;
  }

  // Get user profile
  async getProfile() {
    return this.request<{ success: boolean; data: { user: any } }>('/auth/profile');
  }

  // ==================== SUBSCRIPTION METHODS ====================

  // Create Stripe checkout session
  async createCheckoutSession(priceId: string) {
    const successUrl = `${window.location.origin}/dashboard?success=true`;
    const cancelUrl = `${window.location.origin}/pricing?canceled=true`;

    const response = await this.request<{
      success: boolean;
      data: { sessionId: string; url: string };
    }>('/stripe/create-checkout-session', {
      method: 'POST',
      body: JSON.stringify({ priceId, successUrl, cancelUrl }),
    });

    return response;
  }

  // Get subscription status
  async getSubscriptionStatus() {
    return this.request<{
      success: boolean;
      data: { status: string; subscriptionId: string; details: any };
    }>('/subscription/status');
  }

  // ==================== AI TOOLS METHODS ====================

  // AI Marketing Assistant
  async generateMarketingStrategy(campaignType: string, targetAudience: string, budget: string, goals: string) {
    return this.request<{
      success: boolean;
      data: { marketing_strategy: string; session_id: number };
    }>('/ai/marketing', {
      method: 'POST',
      body: JSON.stringify({ campaignType, targetAudience, budget, goals }),
    });
  }

  // AI Legal Assistant
  async generateLegalAnalysis(legalQuery: string, documentType: string, jurisdiction: string) {
    return this.request<{
      success: boolean;
      data: { legal_analysis: string; session_id: number };
    }>('/ai/legal', {
      method: 'POST',
      body: JSON.stringify({ legalQuery, documentType, jurisdiction }),
    });
  }

  // AI Inventory Management
  async analyzeInventory(currentInventory: any, salesData: any, seasonality: string, leadTime: number) {
    return this.request<{
      success: boolean;
      data: { inventory_analysis: string; session_id: number };
    }>('/ai/inventory', {
      method: 'POST',
      body: JSON.stringify({ currentInventory, salesData, seasonality, leadTime }),
    });
  }

  // AI Logistics Optimizer
  async optimizeLogistics(locations: any[], deliveryRequests: any[], constraints: any) {
    return this.request<{
      success: boolean;
      data: { logistics_optimization: string; session_id: number };
    }>('/ai/logistics', {
      method: 'POST',
      body: JSON.stringify({ locations, deliveryRequests, constraints }),
    });
  }

  // AI Content Creator
  async createContent(contentType: string, topic: string, targetAudience: string, tone: string, length: string) {
    return this.request<{
      success: boolean;
      data: { content: string; session_id: number };
    }>('/ai/content', {
      method: 'POST',
      body: JSON.stringify({ contentType, topic, targetAudience, tone, length }),
    });
  }

  // AI Data Analyst
  async analyzeData(dataset: any, analysisType: string, businessQuestion: string) {
    return this.request<{
      success: boolean;
      data: { analysis: string; session_id: number };
    }>('/ai/data-analysis', {
      method: 'POST',
      body: JSON.stringify({ dataset, analysisType, businessQuestion }),
    });
  }

  // AI Sales Assistant
  async generateSalesStrategy(productInfo: any, prospectInfo: any, salesStage: string, goals: string) {
    return this.request<{
      success: boolean;
      data: { sales_strategy: string; session_id: number };
    }>('/ai/sales', {
      method: 'POST',
      body: JSON.stringify({ productInfo, prospectInfo, salesStage, goals }),
    });
  }

  // AI Customer Support
  async generateSupportResponse(customerIssue: string, ticketType: string, urgency: string, customerHistory: any) {
    return this.request<{
      success: boolean;
      data: { support_response: string; session_id: number };
    }>('/ai/customer-support', {
      method: 'POST',
      body: JSON.stringify({ customerIssue, ticketType, urgency, customerHistory }),
    });
  }

  // AI Email Assistant
  async generateEmail(emailType: string, recipient: string, subject: string, purpose: string, tone: string) {
    return this.request<{
      success: boolean;
      data: { email_content: string; session_id: number };
    }>('/ai/email', {
      method: 'POST',
      body: JSON.stringify({ emailType, recipient, subject, purpose, tone }),
    });
  }

  // AI Document Automation
  async generateDocument(documentType: string, data: any, template: string) {
    return this.request<{
      success: boolean;
      data: { document: string; session_id: number };
    }>('/ai/document', {
      method: 'POST',
      body: JSON.stringify({ documentType, data, template }),
    });
  }

  // ==================== UTILITY METHODS ====================

  // Health check
  async healthCheck() {
    return this.request<{ status: string; timestamp: string; uptime: number }>('/health');
  }

  // Logout
  logout() {
    this.clearToken();
    if (typeof window !== 'undefined') {
      window.location.href = '/';
    }
  }
}

// Create singleton instance
export const apiClient = new ApiClient(API_BASE_URL);

// Export individual methods for convenience
export const {
  signup,
  signin,
  getProfile,
  createCheckoutSession,
  getSubscriptionStatus,
  generateMarketingStrategy,
  generateLegalAnalysis,
  analyzeInventory,
  optimizeLogistics,
  createContent,
  analyzeData,
  generateSalesStrategy,
  generateSupportResponse,
  generateEmail,
  generateDocument,
  healthCheck,
  logout,
} = apiClient;

// Auth hook for React components
export const useAuth = () => {
  const [user, setUser] = React.useState<any>(null);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const initAuth = async () => {
      try {
        const token = localStorage.getItem('auth_token');
        if (token) {
          const profile = await apiClient.getProfile();
          setUser(profile.data.user);
        }
      } catch (error) {
        console.error('Auth initialization error:', error);
        localStorage.removeItem('auth_token');
      } finally {
        setLoading(false);
      }
    };

    initAuth();
  }, []);

  const login = async (email: string, password: string) => {
    const response = await signin(email, password);
    setUser(response.data.user);
    return response;
  };

  const register = async (email: string, password: string, fullName: string) => {
    const response = await signup(email, password, fullName);
    setUser(response.data.user);
    return response;
  };

  const logoutUser = () => {
    logout();
    setUser(null);
  };

  return { user, loading, login, register, logout: logoutUser };
};

export default apiClient;