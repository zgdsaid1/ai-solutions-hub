'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { supabase } from '@/lib/supabase'
import { AI_TOOLS } from '@/lib/constants'
import { callAITool } from '@/lib/ai-tools'
import toast from 'react-hot-toast'
import { LogOut, Sparkles, Loader2, Send } from 'lucide-react'
import Link from 'next/link'
import InventoryTracker from '@/components/InventoryTracker'
import LogisticsOptimizer from '@/components/LogisticsOptimizer'

export default function DashboardPage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [selectedTool, setSelectedTool] = useState<string | null>(null)
  const [prompt, setPrompt] = useState('')
  const [result, setResult] = useState<any>(null)
  const [processing, setProcessing] = useState(false)

  useEffect(() => {
    async function loadUser() {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) {
        router.push('/login')
        return
      }
      setUser(user)
      setLoading(false)
    }
    loadUser()
  }, [router])

  const handleSignOut = async () => {
    await supabase.auth.signOut()
    router.push('/')
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!selectedTool || !prompt.trim()) return

    setProcessing(true)
    setResult(null)

    const tool = AI_TOOLS.find(t => t.id === selectedTool)
    if (!tool) return

    const response = await callAITool(tool.endpoint, {
      toolId: tool.id,
      prompt: prompt.trim(),
    })

    if (response.success) {
      setResult(response.data)
      toast.success('Request completed successfully!')
    } else {
      toast.error(response.error || 'Failed to process request')
    }

    setProcessing(false)
  }

  // Check if the selected tool has a specialized component
  const hasSpecializedComponent = (toolId: string) => {
    return toolId === 'inventory' || toolId === 'logistics'
  }

  // Get specialized component for the selected tool
  const getSpecializedComponent = (toolId: string) => {
    switch (toolId) {
      case 'inventory':
        return <InventoryTracker />
      case 'logistics':
        return <LogisticsOptimizer />
      default:
        return null
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <nav className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/dashboard" className="flex items-center gap-2">
            <Sparkles className="h-8 w-8 text-blue-600" />
            <span className="text-2xl font-bold">AI Solutions Hub</span>
          </Link>
          <div className="flex items-center gap-4">
            <span className="text-gray-600">{user?.email}</span>
            <Link
              href="/pricing"
              className="px-4 py-2 bg-blue-100 text-blue-600 rounded-lg hover:bg-blue-200 transition"
            >
              Upgrade Plan
            </Link>
            <button
              onClick={handleSignOut}
              className="flex items-center gap-2 text-gray-600 hover:text-gray-900"
            >
              <LogOut className="h-5 w-5" />
              Sign Out
            </button>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Welcome to Your AI Dashboard</h1>
          <p className="text-gray-600">Select an AI tool below to get started</p>
        </div>

        {/* Tools Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {AI_TOOLS.map((tool) => (
            <button
              key={tool.id}
              onClick={() => {
                setSelectedTool(tool.id)
                setResult(null) // Clear previous results when switching tools
              }}
              className={`text-left p-6 rounded-xl border-2 transition ${
                selectedTool === tool.id
                  ? 'border-blue-600 bg-blue-50'
                  : 'border-gray-200 bg-white hover:border-blue-300'
              }`}
            >
              <h3 className="text-lg font-semibold mb-2">{tool.name}</h3>
              <p className="text-sm text-gray-600">{tool.description}</p>
              <div className="flex items-center justify-between mt-3">
                <span className="inline-block text-xs bg-blue-100 text-blue-600 px-2 py-1 rounded">
                  {tool.category}
                </span>
                {hasSpecializedComponent(tool.id) && (
                  <span className="text-xs bg-green-100 text-green-600 px-2 py-1 rounded">
                    Advanced
                  </span>
                )}
              </div>
            </button>
          ))}
        </div>

        {/* Tool Interface */}
        {selectedTool && (
          <div className="bg-white rounded-xl shadow-lg">
            {/* Header */}
            <div className="p-8 border-b">
              <h2 className="text-2xl font-bold mb-2">
                {AI_TOOLS.find(t => t.id === selectedTool)?.name}
              </h2>
              {hasSpecializedComponent(selectedTool) ? (
                <p className="text-gray-600">Advanced interface with real-time data management</p>
              ) : (
                <p className="text-gray-600">Enter your request and get AI-powered assistance</p>
              )}
            </div>

            {/* Content */}
            <div className="p-8">
              {hasSpecializedComponent(selectedTool) ? (
                // Specialized Component (Inventory & Logistics)
                getSpecializedComponent(selectedTool)
              ) : (
                // Generic AI Interface
                <div className="space-y-6">
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Enter your request
                      </label>
                      <textarea
                        value={prompt}
                        onChange={(e) => setPrompt(e.target.value)}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent min-h-[120px]"
                        placeholder={`Describe what you need help with for ${AI_TOOLS.find(t => t.id === selectedTool)?.name}...`}
                        required
                      />
                    </div>
                    <button
                      type="submit"
                      disabled={processing}
                      className="flex items-center gap-2 bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {processing ? (
                        <>
                          <Loader2 className="h-5 w-5 animate-spin" />
                          Processing...
                        </>
                      ) : (
                        <>
                          <Send className="h-5 w-5" />
                          Submit
                        </>
                      )}
                    </button>
                  </form>

                  {result && (
                    <div className="mt-8 p-6 bg-gray-50 rounded-lg">
                      <h3 className="text-lg font-semibold mb-4">Result</h3>
                      <pre className="whitespace-pre-wrap text-sm text-gray-700">
                        {JSON.stringify(result, null, 2)}
                      </pre>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}