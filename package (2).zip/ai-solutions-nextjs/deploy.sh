#!/bin/bash

# AI Solutions Hub - Quick Deployment Script
# Run this after adding your API keys to .env.local

set -e

echo "🚀 AI Solutions Hub - Deployment Script"
echo "========================================"

# Check if we're in the right directory
if [ ! -f "package.json" ]; then
    echo "❌ Error: package.json not found. Please run this from /workspace/ai-solutions-nextjs"
    exit 1
fi

# Check for .env.local
if [ ! -f ".env.local" ]; then
    echo "❌ Error: .env.local not found. Please create it with your API keys."
    echo "See DEPLOYMENT_CHECKLIST.md for instructions."
    exit 1
fi

# Check for Stripe keys
if grep -q "pk_test_placeholder" .env.local; then
    echo "⚠️  Warning: Placeholder Stripe keys detected"
    echo "Please update .env.local with real Stripe API keys"
    exit 1
fi

echo "✅ Environment file found"

# Install dependencies
echo ""
echo "📦 Installing dependencies..."
pnpm install

# Build the application
echo ""
echo "🔨 Building application..."
pnpm build

# Check if build succeeded
if [ -d ".next" ]; then
    echo "✅ Build successful!"
else
    echo "❌ Build failed. Check errors above."
    exit 1
fi

echo ""
echo "✅ Application is ready for deployment!"
echo ""
echo "Next steps:"
echo "1. Test locally: pnpm dev"
echo "2. Deploy to Vercel: npx vercel --prod"
echo ""
echo "After deployment:"
echo "- Configure Stripe webhook at: https://dashboard.stripe.com/test/webhooks"
echo "- Webhook URL: https://your-domain.vercel.app/api/webhook"
echo "- Events: checkout.session.completed, customer.subscription.updated, customer.subscription.deleted"
