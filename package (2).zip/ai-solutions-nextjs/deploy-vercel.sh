#!/bin/bash

# AI Solutions Hub - Vercel Deployment Script
# Task 19: Deploy frontend to Vercel

echo "🚀 Deploying AI Solutions Hub to Vercel..."
echo "Target URL: https://aisolutionshub.co"
echo ""

# Check if we're in the right directory
if [ ! -f "package.json" ]; then
    echo "❌ Error: package.json not found. Please run this script from the ai-solutions-nextjs directory."
    exit 1
fi

# Check if Vercel CLI is installed
if ! command -v vercel &> /dev/null; then
    echo "📦 Installing Vercel CLI..."
    npm install -g vercel
fi

# Ensure all environment variables are set
echo "🔍 Checking environment variables..."

# Build the project first
echo "🏗️  Building the project..."
pnpm build

if [ $? -eq 0 ]; then
    echo "✅ Build successful!"
else
    echo "❌ Build failed. Please check for errors."
    exit 1
fi

# Deploy to Vercel
echo ""
echo "🌐 Deploying to Vercel..."
vercel --prod

# Set environment variables after deployment
echo ""
echo "⚙️  Setting up environment variables..."
echo "Please add the following environment variables in your Vercel dashboard:"
echo ""
echo "Environment Variables to set:"
echo "NEXT_PUBLIC_SUPABASE_URL=https://bqvcpbdwjkmbjsynhuqz.supabase.co"
echo "NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJxdmNwYmR3amttYmpzeW5odXF6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjIyMzg5NzksImV4cCI6MjA3NzgxNDk3OX0.1Ze3wURXgaZDC8bgLVBVq0UU8ZRMFtBJkm1Od2zTet0"
echo "NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_live_51SFQiy5QCPSjAcYO2tOpHtcLZXCgmwwhp8ank4G7H2h2OWDeyD7J949ySOyAajvy4S3FzN4u1HJ2JHzvcNXl9Zmz00df8PVz2k"
echo "NEXT_PUBLIC_APP_URL=https://aisolutionshub.co"
echo ""

# Instructions for custom domain
echo "🌐 Custom Domain Setup:"
echo "1. Go to your Vercel project dashboard"
echo "2. Go to Settings > Domains"
echo "3. Add custom domain: aisolutionshub.co"
echo "4. Configure DNS records with your domain provider:"
echo "   A Record: @ -> 76.76.19.61"
echo "   CNAME: www -> cname.vercel-dns.com"
echo ""

echo "✅ Vercel deployment initiated!"
echo "📋 Next steps:"
echo "1. Complete the Vercel CLI deployment process"
echo "2. Set environment variables in Vercel dashboard"
echo "3. Configure custom domain (aisolutionshub.co)"
echo "4. Test the deployed application"
echo ""
echo "🌍 Live URL will be available after deployment completes"
