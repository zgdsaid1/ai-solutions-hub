"use client";

import React, { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/lib/supabase';

interface InventoryItem {
  id: string;
  user_id: string;
  item_name: string;
  current_stock: number;
  alert_threshold: number;
  last_updated: string;
  created_at: string;
}

interface Alert {
  itemId: string;
  itemName: string;
  currentStock: number;
  alertThreshold: number;
  alertType: string;
  message: string;
}

interface Analytics {
  totalItems: number;
  lowStockItems: number;
  criticalStockItems: number;
  totalStock: number;
  healthScore: number;
  lastUpdated: string;
}

export default function InventoryTracker() {
  const { user } = useAuth();
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [analytics, setAnalytics] = useState<Analytics | null>(null);
  const [loading, setLoading] = useState(false);
  const [showAddForm, setShowAddForm] = useState(false);
  const [selectedItem, setSelectedItem] = useState<InventoryItem | null>(null);
  const [predictionData, setPredictionData] = useState<any>(null);

  // Form states
  const [newItem, setNewItem] = useState({
    itemName: '',
    currentStock: 0,
    alertThreshold: 10
  });

  const [updateStockForm, setUpdateStockForm] = useState({
    newStock: 0
  });

  // API call helper
  const callInventoryAPI = async (action: string, data: any = {}) => {
    const response = await fetch(`${process.env.NEXT_PUBLIC_SUPABASE_URL}/functions/v1/ai-inventory-tracker`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${(await supabase.auth.getSession()).data.session?.access_token}`,
      },
      body: JSON.stringify({ action, ...data })
    });

    const result = await response.json();
    if (!response.ok) {
      throw new Error(result.error?.message || 'API call failed');
    }
    return result.data;
  };

  // Load items and alerts
  const loadItems = async () => {
    if (!user) return;
    
    setLoading(true);
    try {
      const data = await callInventoryAPI('get_items', { userId: user.id });
      setItems(data.items || []);
      setAlerts(data.alerts || []);
    } catch (error) {
      console.error('Error loading items:', error);
    }
    setLoading(false);
  };

  // Load analytics
  const loadAnalytics = async () => {
    if (!user) return;
    
    try {
      const data = await callInventoryAPI('analytics', { userId: user.id });
      setAnalytics(data);
    } catch (error) {
      console.error('Error loading analytics:', error);
    }
  };

  // Add new item
  const addItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !newItem.itemName) return;

    setLoading(true);
    try {
      await callInventoryAPI('add_item', {
        userId: user.id,
        itemName: newItem.itemName,
        currentStock: newItem.currentStock,
        alertThreshold: newItem.alertThreshold
      });
      
      setNewItem({ itemName: '', currentStock: 0, alertThreshold: 10 });
      setShowAddForm(false);
      await loadItems();
      await loadAnalytics();
    } catch (error) {
      console.error('Error adding item:', error);
    }
    setLoading(false);
  };

  // Update stock
  const updateStock = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !selectedItem) return;

    setLoading(true);
    try {
      await callInventoryAPI('update_stock', {
        userId: user.id,
        itemId: selectedItem.id,
        currentStock: updateStockForm.newStock
      });
      
      setUpdateStockForm({ newStock: 0 });
      setSelectedItem(null);
      await loadItems();
      await loadAnalytics();
    } catch (error) {
      console.error('Error updating stock:', error);
    }
    setLoading(false);
  };

  // Get demand prediction
  const getPrediction = async (item: InventoryItem) => {
    if (!user) return;

    setLoading(true);
    try {
      const data = await callInventoryAPI('predict_demand', {
        userId: user.id,
        itemName: item.item_name,
        currentStock: item.current_stock,
        alertThreshold: item.alert_threshold,
        historicalData: { // Mock historical data - in real app this would come from database
          last30Days: Array.from({ length: 30 }, (_, i) => ({
            date: new Date(Date.now() - (29 - i) * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
            sales: Math.floor(Math.random() * 50) + 10
          }))
        },
        seasonalFactors: { month: new Date().getMonth() + 1, quarter: Math.ceil((new Date().getMonth() + 1) / 3) },
        marketTrends: { economy: 'stable', industry: 'growing' }
      });
      
      setPredictionData({ item, ...data });
    } catch (error) {
      console.error('Error getting prediction:', error);
    }
    setLoading(false);
  };

  // Send SMS alert
  const sendSMSAlert = async (alert: Alert) => {
    const phoneNumber = prompt('Enter phone number to send SMS alert:');
    if (!phoneNumber) return;

    setLoading(true);
    try {
      await callInventoryAPI('send_alert_sms', {
        phoneNumber,
        alertMessage: alert.message
      });
      alert('SMS alert sent successfully!');
    } catch (error) {
      console.error('Error sending SMS:', error);
      alert('Failed to send SMS alert');
    }
    setLoading(false);
  };

  // Get stock status
  const getStockStatus = (item: InventoryItem) => {
    if (item.current_stock <= 0) return { status: 'OUT_OF_STOCK', color: 'text-red-600', bg: 'bg-red-100' };
    if (item.current_stock <= (item.alert_threshold * 0.5)) return { status: 'CRITICAL', color: 'text-red-500', bg: 'bg-red-50' };
    if (item.current_stock <= item.alert_threshold) return { status: 'LOW', color: 'text-yellow-600', bg: 'bg-yellow-100' };
    return { status: 'GOOD', color: 'text-green-600', bg: 'bg-green-100' };
  };

  useEffect(() => {
    if (user) {
      loadItems();
      loadAnalytics();
    }
  }, [user]);

  if (!user) {
    return (
      <div className="flex items-center justify-center h-64">
        <p className="text-gray-600">Please sign in to access the inventory tracker.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-2xl font-bold text-gray-900">AI Smart Inventory Tracker</h1>
          <div className="flex space-x-3">
            <button
              onClick={() => setShowAddForm(!showAddForm)}
              className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors"
            >
              {showAddForm ? 'Cancel' : 'Add Item'}
            </button>
            <button
              onClick={() => loadItems()}
              className="bg-gray-600 text-white px-4 py-2 rounded-md hover:bg-gray-700 transition-colors"
              disabled={loading}
            >
              Refresh
            </button>
          </div>
        </div>

        {/* Analytics Dashboard */}
        {analytics && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <div className="bg-blue-50 p-4 rounded-lg">
              <h3 className="text-sm font-medium text-blue-600">Total Items</h3>
              <p className="text-2xl font-bold text-blue-800">{analytics.totalItems}</p>
            </div>
            <div className="bg-yellow-50 p-4 rounded-lg">
              <h3 className="text-sm font-medium text-yellow-600">Low Stock</h3>
              <p className="text-2xl font-bold text-yellow-800">{analytics.lowStockItems}</p>
            </div>
            <div className="bg-red-50 p-4 rounded-lg">
              <h3 className="text-sm font-medium text-red-600">Critical Stock</h3>
              <p className="text-2xl font-bold text-red-800">{analytics.criticalStockItems}</p>
            </div>
            <div className="bg-green-50 p-4 rounded-lg">
              <h3 className="text-sm font-medium text-green-600">Health Score</h3>
              <p className="text-2xl font-bold text-green-800">{analytics.healthScore}%</p>
            </div>
          </div>
        )}
      </div>

      {/* Add Item Form */}
      {showAddForm && (
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Add New Inventory Item</h2>
          <form onSubmit={addItem} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">Item Name</label>
              <input
                type="text"
                value={newItem.itemName}
                onChange={(e) => setNewItem({ ...newItem, itemName: e.target.value })}
                className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Current Stock</label>
                <input
                  type="number"
                  value={newItem.currentStock}
                  onChange={(e) => setNewItem({ ...newItem, currentStock: parseInt(e.target.value) })}
                  className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  min="0"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Alert Threshold</label>
                <input
                  type="number"
                  value={newItem.alertThreshold}
                  onChange={(e) => setNewItem({ ...newItem, alertThreshold: parseInt(e.target.value) })}
                  className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  min="1"
                  required
                />
              </div>
            </div>
            <div className="flex space-x-3">
              <button
                type="submit"
                disabled={loading}
                className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors disabled:opacity-50"
              >
                {loading ? 'Adding...' : 'Add Item'}
              </button>
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="bg-gray-300 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-400 transition-colors"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Active Alerts */}
      {alerts.length > 0 && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <h2 className="text-lg font-semibold text-red-800 mb-3">Active Stock Alerts</h2>
          <div className="space-y-2">
            {alerts.map((alert, index) => (
              <div key={index} className="flex items-center justify-between bg-white p-3 rounded border">
                <div>
                  <p className="font-medium text-gray-900">{alert.itemName}</p>
                  <p className="text-sm text-red-600">{alert.message}</p>
                </div>
                <div className="flex space-x-2">
                  <button
                    onClick={() => sendSMSAlert(alert)}
                    className="text-blue-600 hover:text-blue-800 text-sm"
                    disabled={loading}
                  >
                    Send SMS
                  </button>
                  <button
                    onClick={() => {
                      const item = items.find(i => i.id === alert.itemId);
                      if (item) setSelectedItem(item);
                    }}
                    className="text-gray-600 hover:text-gray-800 text-sm"
                  >
                    Update Stock
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Items List */}
      <div className="bg-white rounded-lg shadow">
        <div className="p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Inventory Items</h2>
          {loading ? (
            <p className="text-gray-600">Loading items...</p>
          ) : items.length === 0 ? (
            <p className="text-gray-600">No inventory items found. Add your first item to get started.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Item</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Stock</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Last Updated</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {items.map((item) => {
                    const status = getStockStatus(item);
                    return (
                      <tr key={item.id}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm font-medium text-gray-900">{item.item_name}</div>
                          <div className="text-sm text-gray-500">Threshold: {item.alert_threshold}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900">{item.current_stock}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${status.bg} ${status.color}`}>
                            {status.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {new Date(item.last_updated).toLocaleDateString()}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                          <button
                            onClick={() => setSelectedItem(item)}
                            className="text-blue-600 hover:text-blue-900"
                          >
                            Update
                          </button>
                          <button
                            onClick={() => getPrediction(item)}
                            className="text-green-600 hover:text-green-900"
                            disabled={loading}
                          >
                            AI Prediction
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Update Stock Modal */}
      {selectedItem && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-96">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Update Stock - {selectedItem.item_name}</h2>
            <form onSubmit={updateStock} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">New Stock Level</label>
                <input
                  type="number"
                  value={updateStockForm.newStock}
                  onChange={(e) => setUpdateStockForm({ newStock: parseInt(e.target.value) })}
                  className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  min="0"
                  required
                />
                <p className="text-sm text-gray-500 mt-1">Current: {selectedItem.current_stock} | Alert Threshold: {selectedItem.alert_threshold}</p>
              </div>
              <div className="flex space-x-3">
                <button
                  type="submit"
                  disabled={loading}
                  className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors disabled:opacity-50"
                >
                  {loading ? 'Updating...' : 'Update Stock'}
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedItem(null)}
                  className="bg-gray-300 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-400 transition-colors"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* AI Prediction Modal */}
      {predictionData && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-3/4 max-w-2xl max-h-96 overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-gray-900">AI Demand Prediction - {predictionData.item.item_name}</h2>
              <button
                onClick={() => setPredictionData(null)}
                className="text-gray-400 hover:text-gray-600"
              >
                ✕
              </button>
            </div>
            <div className="space-y-4">
              {predictionData.prediction && (
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h3 className="font-semibold text-blue-800 mb-2">DeepSeek Analysis</h3>
                  <pre className="text-sm text-blue-700 whitespace-pre-wrap">{JSON.stringify(predictionData.prediction, null, 2)}</pre>
                </div>
              )}
              {predictionData.analysis && (
                <div className="bg-green-50 p-4 rounded-lg">
                  <h3 className="font-semibold text-green-800 mb-2">Gemini Analysis</h3>
                  <p className="text-sm text-green-700">{predictionData.analysis}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}