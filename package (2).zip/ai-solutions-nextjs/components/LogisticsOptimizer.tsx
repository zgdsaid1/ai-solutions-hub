"use client";

import React, { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/lib/supabase';
import { MapPin, Truck, Package, Users, Phone, Clock, Navigation } from 'lucide-react';

interface Route {
  id: string;
  user_id: string;
  route_name: string;
  start_location: { lat: number; lng: number; address?: string };
  end_location: { lat: number; lng: number; address?: string };
  waypoints: Array<{ lat: number; lng: number; address?: string }>;
  total_distance_km: number;
  estimated_duration_min: number;
  optimized_route: any;
  status: string;
  created_at: string;
  updated_at: string;
}

interface Driver {
  id: string;
  user_id: string;
  driver_name: string;
  phone_number: string;
  vehicle_type: string;
  license_plate: string;
  current_location: { lat: number; lng: number };
  status: string;
  assigned_routes: string[];
  created_at: string;
  updated_at: string;
}

interface Delivery {
  id: string;
  user_id: string;
  route_id: string;
  driver_id: string;
  delivery_address: { lat: number; lng: number; address: string };
  customer_name: string;
  customer_phone: string;
  package_description: string;
  priority: string;
  status: string;
  delivery_time: string;
  estimated_arrival: string;
  actual_arrival: string;
  notes: string;
  created_at: string;
  updated_at: string;
  routes?: { route_name: string };
  drivers?: { driver_name: string };
}

interface Analytics {
  routes: { total: number; active: number };
  drivers: { total: number; available: number };
  deliveries: { total: number; completed: number; pending: number; completionRate: number };
  performance: { averageDistance: number; onTimeDelivery: number; lastUpdated: string };
}

export default function LogisticsOptimizer() {
  const { user } = useAuth();
  const [routes, setRoutes] = useState<Route[]>([]);
  const [drivers, setDrivers] = useState<Driver[]>([]);
  const [deliveries, setDeliveries] = useState<Delivery[]>([]);
  const [analytics, setAnalytics] = useState<Analytics | null>(null);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [selectedItem, setSelectedItem] = useState<any>(null);

  // Form states
  const [newRoute, setNewRoute] = useState({
    routeName: '',
    startLocation: { lat: 0, lng: 0, address: '' },
    endLocation: { lat: 0, lng: 0, address: '' },
    waypoints: [] as Array<{ lat: number; lng: number; address: string }>
  });

  const [newDriver, setNewDriver] = useState({
    driverName: '',
    phoneNumber: '',
    vehicleType: '',
    licensePlate: '',
    currentLocation: { lat: 0, lng: 0 }
  });

  const [newDelivery, setNewDelivery] = useState({
    deliveryAddress: { lat: 0, lng: 0, address: '' },
    customerName: '',
    customerPhone: '',
    packageDescription: '',
    priority: 'normal',
    deliveryTime: '',
    routeId: ''
  });

  // API call helper
  const callLogisticsAPI = async (action: string, data: any = {}) => {
    const response = await fetch(`${process.env.NEXT_PUBLIC_SUPABASE_URL}/functions/v1/ai-logistics-optimizer`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${(await supabase.auth.getSession()).data.session?.access_token}`,
      },
      body: JSON.stringify({ action, userId: user?.id, ...data })
    });

    const result = await response.json();
    if (!response.ok) {
      throw new Error(result.error?.message || 'API call failed');
    }
    return result.data;
  };

  // Load all data
  const loadData = async () => {
    if (!user) return;
    
    setLoading(true);
    try {
      const [routesData, driversData, deliveriesData, analyticsData] = await Promise.all([
        callLogisticsAPI('get_routes'),
        callLogisticsAPI('get_drivers'),
        callLogisticsAPI('get_deliveries'),
        callLogisticsAPI('analytics')
      ]);
      
      setRoutes(routesData.routes || []);
      setDrivers(driversData.drivers || []);
      setDeliveries(deliveriesData.deliveries || []);
      setAnalytics(analyticsData);
    } catch (error) {
      console.error('Error loading data:', error);
    }
    setLoading(false);
  };

  // Create new route
  const createRoute = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !newRoute.routeName) return;

    setLoading(true);
    try {
      await callLogisticsAPI('create_route', {
        routeName: newRoute.routeName,
        startLocation: newRoute.startLocation,
        endLocation: newRoute.endLocation,
        waypoints: newRoute.waypoints
      });
      
      setNewRoute({
        routeName: '',
        startLocation: { lat: 0, lng: 0, address: '' },
        endLocation: { lat: 0, lng: 0, address: '' },
        waypoints: []
      });
      await loadData();
    } catch (error) {
      console.error('Error creating route:', error);
    }
    setLoading(false);
  };

  // Add new driver
  const addDriver = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !newDriver.driverName) return;

    setLoading(true);
    try {
      await callLogisticsAPI('add_driver', {
        driverName: newDriver.driverName,
        phoneNumber: newDriver.phoneNumber,
        vehicleType: newDriver.vehicleType,
        licensePlate: newDriver.licensePlate,
        currentLocation: newDriver.currentLocation
      });
      
      setNewDriver({
        driverName: '',
        phoneNumber: '',
        vehicleType: '',
        licensePlate: '',
        currentLocation: { lat: 0, lng: 0 }
      });
      await loadData();
    } catch (error) {
      console.error('Error adding driver:', error);
    }
    setLoading(false);
  };

  // Add new delivery
  const addDelivery = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !newDelivery.customerName) return;

    setLoading(true);
    try {
      await callLogisticsAPI('add_delivery', {
        deliveryAddress: newDelivery.deliveryAddress,
        customerName: newDelivery.customerName,
        customerPhone: newDelivery.customerPhone,
        packageDescription: newDelivery.packageDescription,
        priority: newDelivery.priority,
        deliveryTime: newDelivery.deliveryTime,
        routeId: newDelivery.routeId
      });
      
      setNewDelivery({
        deliveryAddress: { lat: 0, lng: 0, address: '' },
        customerName: '',
        customerPhone: '',
        packageDescription: '',
        priority: 'normal',
        deliveryTime: '',
        routeId: ''
      });
      await loadData();
    } catch (error) {
      console.error('Error adding delivery:', error);
    }
    setLoading(false);
  };

  // Update delivery status
  const updateDeliveryStatus = async (deliveryId: string, status: string) => {
    setLoading(true);
    try {
      await callLogisticsAPI('update_delivery_status', {
        deliveryId,
        status,
        estimatedArrivery: new Date(Date.now() + 30 * 60 * 1000).toISOString() // 30 min from now
      });
      await loadData();
    } catch (error) {
      console.error('Error updating delivery status:', error);
    }
    setLoading(false);
  };

  // Get status color
  const getStatusColor = (status: string) => {
    const colorMap: { [key: string]: string } = {
      'pending': 'bg-yellow-100 text-yellow-800',
      'assigned': 'bg-blue-100 text-blue-800',
      'out_for_delivery': 'bg-purple-100 text-purple-800',
      'delivered': 'bg-green-100 text-green-800',
      'delayed': 'bg-orange-100 text-orange-800',
      'failed': 'bg-red-100 text-red-800',
      'available': 'bg-green-100 text-green-800',
      'assigned': 'bg-yellow-100 text-yellow-800',
      'active': 'bg-blue-100 text-blue-800'
    };
    return colorMap[status] || 'bg-gray-100 text-gray-800';
  };

  useEffect(() => {
    if (user) {
      loadData();
    }
  }, [user]);

  if (!user) {
    return (
      <div className="flex items-center justify-center h-64">
        <p className="text-gray-600">Please sign in to access the logistics optimizer.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-2xl font-bold text-gray-900">AI Logistics & Route Optimizer</h1>
          <div className="flex space-x-3">
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`px-4 py-2 rounded-md transition-colors ${activeTab === 'dashboard' ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`}
            >
              Dashboard
            </button>
            <button
              onClick={() => loadData()}
              className="bg-gray-600 text-white px-4 py-2 rounded-md hover:bg-gray-700 transition-colors"
              disabled={loading}
            >
              Refresh
            </button>
          </div>
        </div>

        {/* Analytics Dashboard */}
        {analytics && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <div className="bg-blue-50 p-4 rounded-lg">
              <div className="flex items-center">
                <Navigation className="h-8 w-8 text-blue-600 mr-3" />
                <div>
                  <h3 className="text-sm font-medium text-blue-600">Active Routes</h3>
                  <p className="text-2xl font-bold text-blue-800">{analytics.routes.active}/{analytics.routes.total}</p>
                </div>
              </div>
            </div>
            <div className="bg-green-50 p-4 rounded-lg">
              <div className="flex items-center">
                <Users className="h-8 w-8 text-green-600 mr-3" />
                <div>
                  <h3 className="text-sm font-medium text-green-600">Available Drivers</h3>
                  <p className="text-2xl font-bold text-green-800">{analytics.drivers.available}/{analytics.drivers.total}</p>
                </div>
              </div>
            </div>
            <div className="bg-yellow-50 p-4 rounded-lg">
              <div className="flex items-center">
                <Package className="h-8 w-8 text-yellow-600 mr-3" />
                <div>
                  <h3 className="text-sm font-medium text-yellow-600">Pending Deliveries</h3>
                  <p className="text-2xl font-bold text-yellow-800">{analytics.deliveries.pending}</p>
                </div>
              </div>
            </div>
            <div className="bg-purple-50 p-4 rounded-lg">
              <div className="flex items-center">
                <Truck className="h-8 w-8 text-purple-600 mr-3" />
                <div>
                  <h3 className="text-sm font-medium text-purple-600">Completion Rate</h3>
                  <p className="text-2xl font-bold text-purple-800">{analytics.deliveries.completionRate}%</p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Navigation Tabs */}
      <div className="bg-white rounded-lg shadow">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            {[
              { id: 'routes', label: 'Routes', icon: Navigation },
              { id: 'drivers', label: 'Drivers', icon: Users },
              { id: 'deliveries', label: 'Deliveries', icon: Package },
              { id: 'add', label: 'Add New', icon: MapPin }
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`py-4 px-1 border-b-2 font-medium text-sm flex items-center space-x-2 ${
                    activeTab === tab.id
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        <div className="p-6">
          {/* Routes Tab */}
          {activeTab === 'routes' && (
            <div>
              <h2 className="text-lg font-semibold mb-4">Route Management</h2>
              {loading ? (
                <p className="text-gray-600">Loading routes...</p>
              ) : routes.length === 0 ? (
                <p className="text-gray-600">No routes found. Create your first route to get started.</p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Route Name</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Distance</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Duration</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Created</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {routes.map((route) => (
                        <tr key={route.id} className="hover:bg-gray-50">
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm font-medium text-gray-900">{route.route_name}</div>
                            <div className="text-sm text-gray-500">{route.start_location.address} → {route.end_location.address}</div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {route.total_distance_km ? `${route.total_distance_km.toFixed(1)} km` : 'N/A'}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {route.estimated_duration_min ? `${Math.round(route.estimated_duration_min)} min` : 'N/A'}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(route.status)}`}>
                              {route.status}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {new Date(route.created_at).toLocaleDateString()}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* Drivers Tab */}
          {activeTab === 'drivers' && (
            <div>
              <h2 className="text-lg font-semibold mb-4">Driver Management</h2>
              {loading ? (
                <p className="text-gray-600">Loading drivers...</p>
              ) : drivers.length === 0 ? (
                <p className="text-gray-600">No drivers found. Add your first driver to get started.</p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Driver</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Vehicle</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Phone</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Assigned Routes</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {drivers.map((driver) => (
                        <tr key={driver.id} className="hover:bg-gray-50">
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm font-medium text-gray-900">{driver.driver_name}</div>
                            <div className="text-sm text-gray-500">Plate: {driver.license_plate}</div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {driver.vehicle_type}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {driver.phone_number}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(driver.status)}`}>
                              {driver.status}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {driver.assigned_routes?.length || 0} routes
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* Deliveries Tab */}
          {activeTab === 'deliveries' && (
            <div>
              <h2 className="text-lg font-semibold mb-4">Delivery Tracking</h2>
              {loading ? (
                <p className="text-gray-600">Loading deliveries...</p>
              ) : deliveries.length === 0 ? (
                <p className="text-gray-600">No deliveries found. Add your first delivery to get started.</p>
              ) : (
                <div className="space-y-4">
                  {deliveries.map((delivery) => (
                    <div key={delivery.id} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <div>
                          <h3 className="font-semibold text-gray-900">{delivery.customer_name}</h3>
                          <p className="text-sm text-gray-600">{delivery.delivery_address.address}</p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(delivery.status)}`}>
                            {delivery.status.replace('_', ' ')}
                          </span>
                          {delivery.priority === 'high' && (
                            <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-red-100 text-red-800">
                              HIGH PRIORITY
                            </span>
                          )}
                        </div>
                      </div>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        <div>
                          <span className="text-gray-500">Route:</span>
                          <p className="font-medium">{delivery.routes?.route_name || 'Not assigned'}</p>
                        </div>
                        <div>
                          <span className="text-gray-500">Driver:</span>
                          <p className="font-medium">{delivery.drivers?.driver_name || 'Not assigned'}</p>
                        </div>
                        <div>
                          <span className="text-gray-500">Package:</span>
                          <p className="font-medium">{delivery.package_description}</p>
                        </div>
                        <div>
                          <span className="text-gray-500">Delivery Time:</span>
                          <p className="font-medium">{delivery.delivery_time ? new Date(delivery.delivery_time).toLocaleString() : 'Not scheduled'}</p>
                        </div>
                      </div>
                      {delivery.status === 'pending' && (
                        <div className="mt-3 flex space-x-2">
                          <button
                            onClick={() => updateDeliveryStatus(delivery.id, 'out_for_delivery')}
                            className="bg-blue-600 text-white px-3 py-1 rounded text-sm hover:bg-blue-700"
                          >
                            Mark Out for Delivery
                          </button>
                          <button
                            onClick={() => updateDeliveryStatus(delivery.id, 'delivered')}
                            className="bg-green-600 text-white px-3 py-1 rounded text-sm hover:bg-green-700"
                          >
                            Mark Delivered
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Add New Tab */}
          {activeTab === 'add' && (
            <div className="space-y-6">
              <h2 className="text-lg font-semibold mb-4">Add New Items</h2>
              
              {/* Create Route Form */}
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="font-semibold mb-3">Create New Route</h3>
                <form onSubmit={createRoute} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Route Name</label>
                    <input
                      type="text"
                      value={newRoute.routeName}
                      onChange={(e) => setNewRoute({ ...newRoute, routeName: e.target.value })}
                      className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                    />
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Start Location (Address)</label>
                      <input
                        type="text"
                        value={newRoute.startLocation.address}
                        onChange={(e) => setNewRoute({ 
                          ...newRoute, 
                          startLocation: { ...newRoute.startLocation, address: e.target.value }
                        })}
                        className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="123 Main St, City, State"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">End Location (Address)</label>
                      <input
                        type="text"
                        value={newRoute.endLocation.address}
                        onChange={(e) => setNewRoute({ 
                          ...newRoute, 
                          endLocation: { ...newRoute.endLocation, address: e.target.value }
                        })}
                        className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="456 Oak Ave, City, State"
                        required
                      />
                    </div>
                  </div>
                  <button
                    type="submit"
                    disabled={loading}
                    className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors disabled:opacity-50"
                  >
                    {loading ? 'Creating...' : 'Create Route'}
                  </button>
                </form>
              </div>

              {/* Add Driver Form */}
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="font-semibold mb-3">Add New Driver</h3>
                <form onSubmit={addDriver} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Driver Name</label>
                      <input
                        type="text"
                        value={newDriver.driverName}
                        onChange={(e) => setNewDriver({ ...newDriver, driverName: e.target.value })}
                        className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Phone Number</label>
                      <input
                        type="tel"
                        value={newDriver.phoneNumber}
                        onChange={(e) => setNewDriver({ ...newDriver, phoneNumber: e.target.value })}
                        className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Vehicle Type</label>
                      <input
                        type="text"
                        value={newDriver.vehicleType}
                        onChange={(e) => setNewDriver({ ...newDriver, vehicleType: e.target.value })}
                        className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="Van, Truck, Car, etc."
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">License Plate</label>
                      <input
                        type="text"
                        value={newDriver.licensePlate}
                        onChange={(e) => setNewDriver({ ...newDriver, licensePlate: e.target.value })}
                        className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                      />
                    </div>
                  </div>
                  <button
                    type="submit"
                    disabled={loading}
                    className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 transition-colors disabled:opacity-50"
                  >
                    {loading ? 'Adding...' : 'Add Driver'}
                  </button>
                </form>
              </div>

              {/* Add Delivery Form */}
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="font-semibold mb-3">Add New Delivery</h3>
                <form onSubmit={addDelivery} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Customer Name</label>
                      <input
                        type="text"
                        value={newDelivery.customerName}
                        onChange={(e) => setNewDelivery({ ...newDelivery, customerName: e.target.value })}
                        className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Customer Phone</label>
                      <input
                        type="tel"
                        value={newDelivery.customerPhone}
                        onChange={(e) => setNewDelivery({ ...newDelivery, customerPhone: e.target.value })}
                        className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Delivery Address</label>
                    <input
                      type="text"
                      value={newDelivery.deliveryAddress.address}
                      onChange={(e) => setNewDelivery({ 
                        ...newDelivery, 
                        deliveryAddress: { ...newDelivery.deliveryAddress, address: e.target.value }
                      })}
                      className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="789 Elm St, City, State"
                      required
                    />
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Package Description</label>
                      <input
                        type="text"
                        value={newDelivery.packageDescription}
                        onChange={(e) => setNewDelivery({ ...newDelivery, packageDescription: e.target.value })}
                        className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Priority</label>
                      <select
                        value={newDelivery.priority}
                        onChange={(e) => setNewDelivery({ ...newDelivery, priority: e.target.value })}
                        className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      >
                        <option value="low">Low</option>
                        <option value="normal">Normal</option>
                        <option value="high">High</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Delivery Time</label>
                      <input
                        type="datetime-local"
                        value={newDelivery.deliveryTime}
                        onChange={(e) => setNewDelivery({ ...newDelivery, deliveryTime: e.target.value })}
                        className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Assign to Route (Optional)</label>
                    <select
                      value={newDelivery.routeId}
                      onChange={(e) => setNewDelivery({ ...newDelivery, routeId: e.target.value })}
                      className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="">No route assigned</option>
                      {routes.map((route) => (
                        <option key={route.id} value={route.id}>
                          {route.route_name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <button
                    type="submit"
                    disabled={loading}
                    className="bg-purple-600 text-white px-4 py-2 rounded-md hover:bg-purple-700 transition-colors disabled:opacity-50"
                  >
                    {loading ? 'Adding...' : 'Add Delivery'}
                  </button>
                </form>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}