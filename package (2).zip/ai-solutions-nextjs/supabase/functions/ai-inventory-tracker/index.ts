Deno.serve(async (req) => {
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
        'Access-Control-Max-Age': '86400',
        'Access-Control-Allow-Credentials': 'false'
    };

    if (req.method === 'OPTIONS') {
        return new Response(null, { status: 200, headers: corsHeaders });
    }

    try {
        // Extract parameters from request body
        const requestData = await req.json();
        const { action, userId, itemName, currentStock, alertThreshold, itemId } = requestData;

        // Access environment variables
        const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
        const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
        const twilioAccountSid = Deno.env.get('TWILIO_ACCOUNT_SID')!;
        const twilioAuthToken = Deno.env.get('TWILIO_AUTH_TOKEN')!;
        const twilioPhoneNumber = Deno.env.get('TWILIO_PHONE_NUMBER')!;
        const geminiApiKey = Deno.env.get('GEMINI_API_KEY')!;
        const deepseekApiKey = Deno.env.get('DEEPSEEK_API_KEY')!;

        // Helper function to call Gemini API
        async function callGeminiAPI(prompt: string) {
            const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent?key=${geminiApiKey}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    contents: [{
                        parts: [{ text: prompt }]
                    }]
                })
            });
            const data = await response.json();
            return data.candidates?.[0]?.content?.parts?.[0]?.text || 'AI analysis unavailable';
        }

        // Helper function to call DeepSeek API
        async function callDeepSeekAPI(prompt: string) {
            const response = await fetch('https://api.deepseek.com/v1/chat/completions', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${deepseekApiKey}`
                },
                body: JSON.stringify({
                    model: 'deepseek-chat',
                    messages: [{ role: 'user', content: prompt }],
                    max_tokens: 500
                })
            });
            const data = await response.json();
            return data.choices?.[0]?.message?.content || 'AI analysis unavailable';
        }

        // Helper function to send Twilio SMS
        async function sendSMS(to: string, message: string) {
            const authString = btoa(`${twilioAccountSid}:${twilioAuthToken}`);
            const response = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${twilioAccountSid}/Messages.json`, {
                method: 'POST',
                headers: {
                    'Authorization': `Basic ${authString}`,
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: new URLSearchParams({
                    To: to,
                    From: twilioPhoneNumber,
                    Body: message
                })
            });
            return response.ok;
        }

        // Helper function to check stock levels and send alerts
        async function checkStockLevels(userId: string) {
            const response = await fetch(`${supabaseUrl}/rest/v1/inventory_items?user_id=eq.${userId}&select=*`, {
                headers: {
                    'Authorization': `Bearer ${supabaseServiceKey}`,
                    'apikey': supabaseServiceKey,
                    'Content-Type': 'application/json'
                }
            });
            const items = await response.json();
            
            const alerts = [];
            for (const item of items) {
                if (item.current_stock <= item.alert_threshold) {
                    // Check if this is a critical low stock (below 50% of threshold)
                    const isCritical = item.current_stock <= (item.alert_threshold * 0.5);
                    const alertType = isCritical ? 'CRITICAL' : 'LOW';
                    
                    alerts.push({
                        itemId: item.id,
                        itemName: item.item_name,
                        currentStock: item.current_stock,
                        alertThreshold: item.alert_threshold,
                        alertType,
                        message: `${alertType} STOCK ALERT: ${item.item_name} is running low! Current stock: ${item.current_stock}, Alert threshold: ${item.alert_threshold}. ${isCritical ? 'This is CRITICAL - order more immediately!' : 'Consider reordering soon.'}`
                    });
                }
            }
            return alerts;
        }

        // Route handling
        switch (action) {
            case 'add_item':
                // Add new inventory item
                const addResponse = await fetch(`${supabaseUrl}/rest/v1/inventory_items`, {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${supabaseServiceKey}`,
                        'apikey': supabaseServiceKey,
                        'Content-Type': 'application/json',
                        'Prefer': 'return=representation'
                    },
                    body: JSON.stringify({
                        user_id: userId,
                        item_name: itemName,
                        current_stock: currentStock || 0,
                        alert_threshold: alertThreshold || 10
                    })
                });
                const newItem = await addResponse.json();
                
                // Check for immediate alerts on new item
                if (currentStock <= (alertThreshold || 10)) {
                    const alerts = await checkStockLevels(userId);
                    return new Response(JSON.stringify({ 
                        data: { 
                            item: newItem[0], 
                            alerts: alerts.filter(alert => alert.itemName === itemName)
                        } 
                    }), {
                        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
                    });
                }
                
                return new Response(JSON.stringify({ data: { item: newItem[0] } }), {
                    headers: { ...corsHeaders, 'Content-Type': 'application/json' }
                });

            case 'update_stock':
                // Update stock level
                const updateResponse = await fetch(`${supabaseUrl}/rest/v1/inventory_items?id=eq.${itemId}`, {
                    method: 'PATCH',
                    headers: {
                        'Authorization': `Bearer ${supabaseServiceKey}`,
                        'apikey': supabaseServiceKey,
                        'Content-Type': 'application/json',
                        'Prefer': 'return=representation'
                    },
                    body: JSON.stringify({
                        current_stock: currentStock,
                        last_updated: new Date().toISOString()
                    })
                });
                const updatedItem = await updateResponse.json();
                
                // Check for alerts after stock update
                const stockAlerts = await checkStockLevels(userId);
                const thisItemAlerts = stockAlerts.filter(alert => alert.itemId === itemId);
                
                return new Response(JSON.stringify({ 
                    data: { 
                        item: updatedItem[0], 
                        alerts: thisItemAlerts
                    } 
                }), {
                    headers: { ...corsHeaders, 'Content-Type': 'application/json' }
                });

            case 'get_items':
                // Get all inventory items for user
                const itemsResponse = await fetch(`${supabaseUrl}/rest/v1/inventory_items?user_id=eq.${userId}&select=*&order=created_at.desc`, {
                    headers: {
                        'Authorization': `Bearer ${supabaseServiceKey}`,
                        'apikey': supabaseServiceKey,
                        'Content-Type': 'application/json'
                    }
                });
                const items = await itemsResponse.json();
                
                // Check for any alerts
                const alerts = await checkStockLevels(userId);
                
                return new Response(JSON.stringify({ data: { items, alerts } }), {
                    headers: { ...corsHeaders, 'Content-Type': 'application/json' }
                });

            case 'predict_demand':
                // AI-powered demand prediction
                const { historicalData, seasonalFactors, marketTrends } = requestData;
                
                const predictionPrompt = `Based on the following inventory data, predict demand patterns and provide reorder recommendations:

Item: ${itemName}
Current Stock: ${currentStock}
Alert Threshold: ${alertThreshold}

Historical Data: ${JSON.stringify(historicalData)}
Seasonal Factors: ${JSON.stringify(seasonalFactors)}
Market Trends: ${JSON.stringify(marketTrends)}

Please provide:
1. Demand forecast for next 30 days
2. Optimal reorder quantity
3. Reorder timing recommendation
4. Potential stockout risk assessment
5. Seasonal adjustment factors

Return in JSON format with clear structure.`;

                // Use DeepSeek for prediction (better for structured analysis)
                const prediction = await callDeepSeekAPI(predictionPrompt);
                
                // Also get Gemini analysis for alternative perspective
                const geminiAnalysis = await callGeminiAPI(`Analyze inventory demand patterns for ${itemName} with current stock ${currentStock}. Provide insights on reorder timing and quantity recommendations.`);

                return new Response(JSON.stringify({ 
                    data: { 
                        prediction: JSON.parse(prediction || '{}'),
                        analysis: geminiAnalysis,
                        timestamp: new Date().toISOString()
                    } 
                }), {
                    headers: { ...corsHeaders, 'Content-Type': 'application/json' }
                });

            case 'check_alerts':
                // Manual alert check
                const allAlerts = await checkStockLevels(userId);
                
                return new Response(JSON.stringify({ data: { alerts: allAlerts } }), {
                    headers: { ...corsHeaders, 'Content-Type': 'application/json' }
                });

            case 'send_alert_sms':
                // Send SMS alert
                const { phoneNumber, alertMessage } = requestData;
                const smsSent = await sendSMS(phoneNumber, alertMessage);
                
                return new Response(JSON.stringify({ 
                    data: { 
                        smsSent,
                        message: smsSent ? 'SMS alert sent successfully' : 'Failed to send SMS alert'
                    } 
                }), {
                    headers: { ...corsHeaders, 'Content-Type': 'application/json' }
                });

            case 'bulk_update':
                // Bulk update multiple items
                const { updates } = requestData; // Array of {itemId, newStock}
                const updateResults = [];
                
                for (const update of updates) {
                    const bulkUpdateResponse = await fetch(`${supabaseUrl}/rest/v1/inventory_items?id=eq.${update.itemId}`, {
                        method: 'PATCH',
                        headers: {
                            'Authorization': `Bearer ${supabaseServiceKey}`,
                            'apikey': supabaseServiceKey,
                            'Content-Type': 'application/json',
                            'Prefer': 'return=representation'
                        },
                        body: JSON.stringify({
                            current_stock: update.newStock,
                            last_updated: new Date().toISOString()
                        })
                    });
                    const result = await bulkUpdateResponse.json();
                    updateResults.push(result[0]);
                }
                
                // Check for alerts after bulk update
                const bulkAlerts = await checkStockLevels(userId);
                
                return new Response(JSON.stringify({ 
                    data: { 
                        updatedItems: updateResults,
                        alerts: bulkAlerts
                    } 
                }), {
                    headers: { ...corsHeaders, 'Content-Type': 'application/json' }
                });

            case 'analytics':
                // Get inventory analytics
                const analyticsResponse = await fetch(`${supabaseUrl}/rest/v1/inventory_items?user_id=eq.${userId}&select=*`, {
                    headers: {
                        'Authorization': `Bearer ${supabaseServiceKey}`,
                        'apikey': supabaseServiceKey,
                        'Content-Type': 'application/json'
                    }
                });
                const allItemsResponse = await analyticsResponse.json();
                const allItems = Array.isArray(allItemsResponse) ? allItemsResponse : [];
                
                const totalItems = allItems.length;
                const lowStockItems = allItems.filter((item: any) => item.current_stock <= item.alert_threshold).length;
                const criticalStockItems = allItems.filter((item: any) => item.current_stock <= (item.alert_threshold * 0.5)).length;
                const totalValue = allItems.reduce((sum: number, item: any) => sum + item.current_stock, 0);
                
                const analytics = {
                    totalItems,
                    lowStockItems,
                    criticalStockItems,
                    totalStock: totalValue,
                    healthScore: totalItems > 0 ? Math.round(((totalItems - criticalStockItems) / totalItems) * 100) : 100,
                    lastUpdated: new Date().toISOString()
                };
                
                return new Response(JSON.stringify({ data: analytics }), {
                    headers: { ...corsHeaders, 'Content-Type': 'application/json' }
                });

            default:
                return new Response(JSON.stringify({ 
                    error: { 
                        code: 'INVALID_ACTION', 
                        message: 'Invalid action. Supported actions: add_item, update_stock, get_items, predict_demand, check_alerts, send_alert_sms, bulk_update, analytics' 
                    } 
                }), {
                    status: 400,
                    headers: { ...corsHeaders, 'Content-Type': 'application/json' }
                });
        }

    } catch (error) {
        // Return error response
        const errorResponse = {
            error: {
                code: 'INVENTORY_TRACKER_ERROR',
                message: error.message
            }
        };

        return new Response(JSON.stringify(errorResponse), {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    }
});