Deno.serve(async (req) => {
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
        'Access-Control-Max-Age': '86400',
        'Access-Control-Allow-Credentials': 'false'
    };

    if (req.method === 'OPTIONS') {
        return new Response(null, { status: 200, headers: corsHeaders });
    }

    try {
        // Extract parameters from request body
        const requestData = await req.json();
        const { action, userId } = requestData;

        // Access environment variables
        const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
        const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
        const googleMapsApiKey = Deno.env.get('GOOGLE_MAPS_API_KEY')!;
        const twilioAccountSid = Deno.env.get('TWILIO_ACCOUNT_SID')!;
        const twilioAuthToken = Deno.env.get('TWILIO_AUTH_TOKEN')!;
        const twilioPhoneNumber = Deno.env.get('TWILIO_PHONE_NUMBER')!;
        const geminiApiKey = Deno.env.get('GEMINI_API_KEY')!;
        const deepseekApiKey = Deno.env.get('DEEPSEEK_API_KEY')!;

        // Helper function to send Twilio SMS
        async function sendSMS(to: string, message: string) {
            const authString = btoa(`${twilioAccountSid}:${twilioAuthToken}`);
            const response = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${twilioAccountSid}/Messages.json`, {
                method: 'POST',
                headers: {
                    'Authorization': `Basic ${authString}`,
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: new URLSearchParams({
                    To: to,
                    From: twilioPhoneNumber,
                    Body: message
                })
            });
            return response.ok;
        }

        // Helper function to get route from Google Maps API
        async function getRouteOptimization(startLocation: any, endLocation: any, waypoints: any[] = []) {
            const waypointsParam = waypoints.length > 0 
                ? `&waypoints=optimize:true|${waypoints.map(wp => `${wp.lat},${wp.lng}`).join('|')}`
                : '';
            
            const url = `https://maps.googleapis.com/maps/api/directions/json?origin=${startLocation.lat},${startLocation.lng}&destination=${endLocation.lat},${endLocation.lng}${waypointsParam}&key=${googleMapsApiKey}`;
            
            const response = await fetch(url);
            const data = await response.json();
            
            if (data.status !== 'OK') {
                throw new Error(`Google Maps API error: ${data.status}`);
            }

            const route = data.routes[0];
            const leg = route.legs[0];
            
            return {
                optimizedRoute: route,
                distance: leg.distance,
                duration: leg.duration,
                startAddress: leg.start_address,
                endAddress: leg.end_address,
                polyline: route.overview_polyline.points
            };
        }

        // Route handling
        switch (action) {
            case 'create_route':
                const { routeName, startLocation, endLocation, waypoints = [] } = requestData;
                
                // Get optimized route from Google Maps
                const routeData = await getRouteOptimization(startLocation, endLocation, waypoints);
                
                // Create route in database
                const createResponse = await fetch(`${supabaseUrl}/rest/v1/routes`, {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${supabaseServiceKey}`,
                        'apikey': supabaseServiceKey,
                        'Content-Type': 'application/json',
                        'Prefer': 'return=representation'
                    },
                    body: JSON.stringify({
                        user_id: userId,
                        route_name: routeName,
                        start_location: startLocation,
                        end_location: endLocation,
                        waypoints: waypoints,
                        total_distance_km: routeData.distance.value / 1000,
                        estimated_duration_min: routeData.duration.value / 60,
                        optimized_route: routeData.optimizedRoute
                    })
                });
                const newRoute = await createResponse.json();
                
                return new Response(JSON.stringify({ data: { route: newRoute[0], routeData } }), {
                    headers: { ...corsHeaders, 'Content-Type': 'application/json' }
                });

            case 'add_driver':
                const { driverName, phoneNumber, vehicleType, licensePlate, currentLocation } = requestData;
                
                const driverResponse = await fetch(`${supabaseUrl}/rest/v1/drivers`, {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${supabaseServiceKey}`,
                        'apikey': supabaseServiceKey,
                        'Content-Type': 'application/json',
                        'Prefer': 'return=representation'
                    },
                    body: JSON.stringify({
                        user_id: userId,
                        driver_name: driverName,
                        phone_number: phoneNumber,
                        vehicle_type: vehicleType,
                        license_plate: licensePlate,
                        current_location: currentLocation || { lat: 0, lng: 0 }
                    })
                });
                const newDriver = await driverResponse.json();
                
                return new Response(JSON.stringify({ data: { driver: newDriver[0] } }), {
                    headers: { ...corsHeaders, 'Content-Type': 'application/json' }
                });

            case 'add_delivery':
                const { deliveryAddress, customerName, customerPhone, packageDescription, priority = 'normal', deliveryTime, routeId: deliveryRouteId } = requestData;
                
                const deliveryResponse = await fetch(`${supabaseUrl}/rest/v1/deliveries`, {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${supabaseServiceKey}`,
                        'apikey': supabaseServiceKey,
                        'Content-Type': 'application/json',
                        'Prefer': 'return=representation'
                    },
                    body: JSON.stringify({
                        user_id: userId,
                        route_id: deliveryRouteId,
                        delivery_address: deliveryAddress,
                        customer_name: customerName,
                        customer_phone: customerPhone,
                        package_description: packageDescription,
                        priority,
                        status: 'pending',
                        delivery_time: deliveryTime
                    })
                });
                const newDelivery = await deliveryResponse.json();
                
                // Send confirmation SMS to customer
                if (customerPhone) {
                    try {
                        await sendSMS(customerPhone, 
                            `Your delivery has been scheduled for ${deliveryTime ? new Date(deliveryTime).toLocaleString() : 'today'}. We'll keep you updated on the progress.`);
                    } catch (smsError) {
                        console.log('SMS error:', smsError);
                    }
                }
                
                return new Response(JSON.stringify({ data: { delivery: newDelivery[0] } }), {
                    headers: { ...corsHeaders, 'Content-Type': 'application/json' }
                });

            case 'update_delivery_status':
                const { deliveryId, status, estimatedArrival, notes } = requestData;
                
                const updateResponse = await fetch(`${supabaseUrl}/rest/v1/deliveries?id=eq.${deliveryId}`, {
                    method: 'PATCH',
                    headers: {
                        'Authorization': `Bearer ${supabaseServiceKey}`,
                        'apikey': supabaseServiceKey,
                        'Content-Type': 'application/json',
                        'Prefer': 'return=representation'
                    },
                    body: JSON.stringify({
                        status,
                        estimated_arrival: estimatedArrival,
                        actual_arrival: status === 'delivered' ? new Date().toISOString() : null,
                        notes,
                        updated_at: new Date().toISOString()
                    })
                });
                const updatedDelivery = await updateResponse.json();
                
                return new Response(JSON.stringify({ data: { delivery: updatedDelivery[0] } }), {
                    headers: { ...corsHeaders, 'Content-Type': 'application/json' }
                });

            case 'get_routes':
                const routesResponse = await fetch(`${supabaseUrl}/rest/v1/routes?user_id=eq.${userId}&select=*&order=created_at.desc`, {
                    headers: {
                        'Authorization': `Bearer ${supabaseServiceKey}`,
                        'apikey': supabaseServiceKey,
                        'Content-Type': 'application/json'
                    }
                });
                const routes = await routesResponse.json();
                
                return new Response(JSON.stringify({ data: { routes: Array.isArray(routes) ? routes : [] } }), {
                    headers: { ...corsHeaders, 'Content-Type': 'application/json' }
                });

            case 'get_drivers':
                const driversResponse = await fetch(`${supabaseUrl}/rest/v1/drivers?user_id=eq.${userId}&select=*&order=created_at.desc`, {
                    headers: {
                        'Authorization': `Bearer ${supabaseServiceKey}`,
                        'apikey': supabaseServiceKey,
                        'Content-Type': 'application/json'
                    }
                });
                const drivers = await driversResponse.json();
                
                return new Response(JSON.stringify({ data: { drivers: Array.isArray(drivers) ? drivers : [] } }), {
                    headers: { ...corsHeaders, 'Content-Type': 'application/json' }
                });

            case 'get_deliveries':
                const deliveriesResponse = await fetch(`${supabaseUrl}/rest/v1/deliveries?user_id=eq.${userId}&select=*,routes(route_name),drivers(driver_name)&order=created_at.desc`, {
                    headers: {
                        'Authorization': `Bearer ${supabaseServiceKey}`,
                        'apikey': supabaseServiceKey,
                        'Content-Type': 'application/json'
                    }
                });
                const deliveries = await deliveriesResponse.json();
                
                return new Response(JSON.stringify({ data: { deliveries: Array.isArray(deliveries) ? deliveries : [] } }), {
                    headers: { ...corsHeaders, 'Content-Type': 'application/json' }
                });

            case 'analytics':
                // Get logistics analytics
                const [routesAnalytics, driversAnalytics, deliveriesAnalytics] = await Promise.all([
                    fetch(`${supabaseUrl}/rest/v1/routes?user_id=eq.${userId}&select=*`, {
                        headers: { 'Authorization': `Bearer ${supabaseServiceKey}`, 'apikey': supabaseServiceKey }
                    }),
                    fetch(`${supabaseUrl}/rest/v1/drivers?user_id=eq.${userId}&select=*`, {
                        headers: { 'Authorization': `Bearer ${supabaseServiceKey}`, 'apikey': supabaseServiceKey }
                    }),
                    fetch(`${supabaseUrl}/rest/v1/deliveries?user_id=eq.${userId}&select=*`, {
                        headers: { 'Authorization': `Bearer ${supabaseServiceKey}`, 'apikey': supabaseServiceKey }
                    })
                ]);
                
                const [routesData, driversData, deliveriesData] = await Promise.all([
                    routesAnalytics.json(),
                    driversAnalytics.json(),
                    deliveriesAnalytics.json()
                ]);
                
                const routesArr = Array.isArray(routesData) ? routesData : [];
                const driversArr = Array.isArray(driversData) ? driversData : [];
                const deliveriesArr = Array.isArray(deliveriesData) ? deliveriesData : [];
                
                const totalRoutes = routesArr.length;
                const activeRoutes = routesArr.filter((r: any) => r.status === 'active').length;
                const totalDrivers = driversArr.length;
                const availableDrivers = driversArr.filter((d: any) => d.status === 'available').length;
                const totalDeliveries = deliveriesArr.length;
                const completedDeliveries = deliveriesArr.filter((d: any) => d.status === 'delivered').length;
                const pendingDeliveries = deliveriesArr.filter((d: any) => d.status === 'pending').length;
                
                const analytics = {
                    routes: { total: totalRoutes, active: activeRoutes },
                    drivers: { total: totalDrivers, available: availableDrivers },
                    deliveries: { 
                        total: totalDeliveries, 
                        completed: completedDeliveries, 
                        pending: pendingDeliveries,
                        completionRate: totalDeliveries > 0 ? Math.round((completedDeliveries / totalDeliveries) * 100) : 0
                    },
                    performance: {
                        averageDistance: totalRoutes > 0 ? routesArr.reduce((sum: number, r: any) => sum + (r.total_distance_km || 0), 0) / totalRoutes : 0,
                        onTimeDelivery: completedDeliveries,
                        lastUpdated: new Date().toISOString()
                    }
                };
                
                return new Response(JSON.stringify({ data: analytics }), {
                    headers: { ...corsHeaders, 'Content-Type': 'application/json' }
                });

            case 'optimize_routes':
                // AI-powered route optimization
                const { routes: routeList } = requestData;
                
                const optimization = {
                    optimizedRoutes: routeList,
                    recommendations: [
                        "Use morning hours (7-10 AM) to avoid traffic",
                        "Group deliveries by geographic proximity",
                        "Consider weather conditions for outdoor deliveries",
                        "Use real-time traffic data for dynamic routing"
                    ],
                    efficiencyScore: 85,
                    timestamp: new Date().toISOString()
                };
                
                return new Response(JSON.stringify({ data: { optimization } }), {
                    headers: { ...corsHeaders, 'Content-Type': 'application/json' }
                });

            default:
                return new Response(JSON.stringify({ 
                    error: { 
                        code: 'INVALID_ACTION', 
                        message: 'Invalid action. Supported actions: create_route, add_driver, add_delivery, update_delivery_status, get_routes, get_drivers, get_deliveries, analytics, optimize_routes' 
                    } 
                }), {
                    status: 400,
                    headers: { ...corsHeaders, 'Content-Type': 'application/json' }
                });
        }

    } catch (error) {
        // Return error response
        const errorResponse = {
            error: {
                code: 'LOGISTICS_OPTIMIZER_ERROR',
                message: error.message
            }
        };

        return new Response(JSON.stringify(errorResponse), {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    }
});