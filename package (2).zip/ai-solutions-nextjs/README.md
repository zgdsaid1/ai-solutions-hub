# AI Solutions Hub

A comprehensive business automation platform featuring 10 AI-powered tools for entrepreneurs, businesses, and professionals.

## 🚀 Live Demo

**Production URL:** [https://aisolutionshub.co](https://aisolutionshub.co)

## ✨ Features

### 10 AI-Powered Business Tools

#### 1. **Marketing Content Generator**
- AI-generated marketing copy, product descriptions, and campaign materials
- Target audience optimization
- Multiple content formats (social media, email, ads)

#### 2. **Legal Document Drafting**
- Contract templates and legal document generation
- Compliance checking and risk assessment
- Legal terminology and clause suggestions

#### 3. **Data Analytics & Insights**
- Business data analysis and visualization
- Trend identification and reporting
- Performance metrics and KPI tracking

#### 4. **Email Marketing Automation**
- Personalized email campaign generation
- A/B testing suggestions
- Lead nurturing sequences

#### 5. **Document Summarization**
- AI-powered document analysis and summarization
- Key points extraction
- Multi-language support

#### 6. **Customer Support Assistant**
- Automated response generation
- FAQ creation and management
- Customer inquiry classification

#### 7. **Sales Analytics**
- Sales performance tracking
- Lead scoring and conversion analysis
- Revenue forecasting

#### 8. **Content Creation**
- Blog posts, articles, and web content
- SEO optimization
- Brand voice consistency

#### 9. **AI Smart Inventory Tracker**
- Real-time stock monitoring and alerts
- AI-powered demand prediction
- Automated low-stock notifications via SMS
- Inventory analytics and optimization

#### 10. **AI Logistics & Route Optimizer**
- Delivery route optimization
- Driver assignment and tracking
- Real-time delivery status updates
- Performance analytics for logistics operations

## 🛠 Tech Stack

### Frontend
- **Next.js 14** - React framework with App Router
- **TypeScript** - Type-safe development
- **Tailwind CSS** - Utility-first CSS framework
- **Lucide React** - Icon library
- **React Hot Toast** - Notification system

### Backend
- **Supabase** - Backend-as-a-Service
- **Edge Functions** - Serverless TypeScript functions
- **PostgreSQL** - Database with RLS
- **Row Level Security** - User data isolation

### AI & APIs
- **OpenAI GPT-4o-mini** - AI content generation
- **Google Gemini** - Alternative AI model
- **Google Maps API** - Route optimization and location services
- **Twilio** - SMS notifications and alerts
- **DocuSign** - Document signing and management

### Payments
- **Stripe** - Subscription billing and payments
- **Webhook integration** - Real-time payment processing

## 🏗 Project Structure

```
ai-solutions-nextjs/
├── app/                    # Next.js App Router
│   ├── api/               # API routes
│   ├── dashboard/         # Main dashboard page
│   ├── tools/             # Individual tool pages
│   ├── pricing/           # Pricing and billing
│   ├── login/             # Authentication pages
│   └── signup/            # User registration
├── components/            # React components
│   ├── InventoryTracker.tsx     # Inventory management UI
│   └── LogisticsOptimizer.tsx   # Logistics management UI
├── lib/                   # Utility libraries
│   ├── ai-tools.ts        # AI tool configurations
│   ├── constants.ts       # App constants
│   ├── supabase.ts        # Supabase client
│   └── supabase-server.ts # Server-side utilities
├── supabase/              # Supabase configuration
│   └── functions/         # Edge functions
│       ├── ai-marketing-generator/
│       ├── ai-legal-drafting/
│       ├── ai-data-analytics/
│       ├── ai-email-marketing/
│       ├── ai-document-summarization/
│       ├── ai-customer-support/
│       ├── ai-sales-analytics/
│       ├── ai-content-creation/
│       ├── ai-inventory-tracker/
│       └── ai-logistics-optimizer/
└── public/                # Static assets
```

## 🚀 Quick Start

### Prerequisites
- Node.js 18+ 
- pnpm (recommended) or npm
- Supabase account
- Stripe account

### 1. Clone & Install
```bash
git clone https://github.com/zgdsait1/Database.git
cd Database
pnpm install
```

### 2. Environment Configuration
```bash
cp .env.local.example .env.local
```

Update `.env.local` with your credentials:
```env
# Supabase
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key

# Stripe
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=your_stripe_publishable_key
STRIPE_SECRET_KEY=your_stripe_secret_key
STRIPE_WEBHOOK_SECRET=your_stripe_webhook_secret

# App
NEXT_PUBLIC_APP_URL=https://aisolutionshub.co
```

### 3. Database Setup
Run the following SQL in your Supabase SQL editor:

```sql
-- Core tables for generic AI tools
CREATE TABLE ai_queries (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id),
    tool_type VARCHAR(50) NOT NULL,
    query TEXT,
    response TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Inventory tracking tables
CREATE TABLE inventory_items (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id),
    item_name VARCHAR(255) NOT NULL,
    sku VARCHAR(100),
    current_stock INTEGER DEFAULT 0,
    alert_threshold INTEGER DEFAULT 10,
    unit VARCHAR(50) DEFAULT 'units',
    last_updated TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Logistics tables
CREATE TABLE routes (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id),
    route_name VARCHAR(255),
    start_location TEXT,
    end_location TEXT,
    waypoints TEXT[],
    total_distance_km DECIMAL(10,2),
    estimated_time_minutes INTEGER,
    status VARCHAR(50) DEFAULT 'pending',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE drivers (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id),
    driver_name VARCHAR(255),
    phone VARCHAR(20),
    vehicle_type VARCHAR(100),
    status VARCHAR(50) DEFAULT 'available',
    current_location TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE deliveries (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id),
    route_id UUID REFERENCES routes(id),
    driver_id UUID REFERENCES drivers(id),
    customer_name VARCHAR(255),
    delivery_address TEXT,
    status VARCHAR(50) DEFAULT 'pending',
    scheduled_time TIMESTAMP WITH TIME ZONE,
    actual_time TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE ai_queries ENABLE ROW LEVEL SECURITY;
ALTER TABLE inventory_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE routes ENABLE ROW LEVEL SECURITY;
ALTER TABLE drivers ENABLE ROW LEVEL SECURITY;
ALTER TABLE deliveries ENABLE ROW LEVEL SECURITY;

-- Create policies for public access (for testing)
CREATE POLICY "Allow public read access" ON ai_queries FOR SELECT USING (true);
CREATE POLICY "Allow public insert" ON ai_queries FOR INSERT WITH CHECK (true);

CREATE POLICY "Allow public read access" ON inventory_items FOR SELECT USING (true);
CREATE POLICY "Allow public insert" ON inventory_items FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update" ON inventory_items FOR UPDATE USING (true);
CREATE POLICY "Allow public delete" ON inventory_items FOR DELETE USING (true);

CREATE POLICY "Allow public read access" ON routes FOR SELECT USING (true);
CREATE POLICY "Allow public insert" ON routes FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update" ON routes FOR UPDATE USING (true);
CREATE POLICY "Allow public delete" ON routes FOR DELETE USING (true);

CREATE POLICY "Allow public read access" ON drivers FOR SELECT USING (true);
CREATE POLICY "Allow public insert" ON drivers FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update" ON drivers FOR UPDATE USING (true);
CREATE POLICY "Allow public delete" ON drivers FOR DELETE USING (true);

CREATE POLICY "Allow public read access" ON deliveries FOR SELECT USING (true);
CREATE POLICY "Allow public insert" ON deliveries FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update" ON deliveries FOR UPDATE USING (true);
CREATE POLICY "Allow public delete" ON deliveries FOR DELETE USING (true);
```

### 4. Deploy Edge Functions
Install Supabase CLI and deploy functions:
```bash
npm install -g supabase
supabase login
supabase functions deploy --project-ref bqvcpbdwjkmbjsynhuqz
```

### 5. Start Development
```bash
pnpm dev
```

Visit `http://localhost:3000` to see the application.

## 🔧 Edge Functions

All 10 AI tools are implemented as Supabase Edge Functions:

1. **ai-marketing-generator** - Marketing content generation
2. **ai-legal-drafting** - Legal document creation
3. **ai-data-analytics** - Business data analysis
4. **ai-email-marketing** - Email campaign automation
5. **ai-document-summarization** - Document processing
6. **ai-customer-support** - Support automation
7. **ai-sales-analytics** - Sales intelligence
8. **ai-content-creation** - Content generation
9. **ai-inventory-tracker** - Inventory management with AI
10. **ai-logistics-optimizer** - Route optimization and delivery

## 🎯 Usage Examples

### Using Generic AI Tools
1. Navigate to dashboard
2. Select any tool from the grid
3. Enter your requirements
4. Get AI-powered results instantly

### Inventory Tracking
1. Go to "AI Smart Inventory Tracker"
2. Add new items with stock levels and thresholds
3. Set up automatic low-stock alerts
4. View AI-powered demand predictions

### Logistics Optimization
1. Access "AI Logistics & Route Optimizer"
2. Create delivery routes with multiple stops
3. Assign drivers to routes
4. Track delivery status in real-time
5. Get AI optimization suggestions

## 🚀 Deployment

### Frontend (Vercel)
1. Connect your GitHub repository to Vercel
2. Set environment variables in Vercel dashboard
3. Deploy automatically on push to main branch

### Backend (Railway)
1. Connect repository to Railway
2. Configure environment variables
3. Deploy edge functions

## 📊 Features by Tool

| Tool | AI Model | Key Features | API Integrations |
|------|----------|-------------|------------------|
| Marketing Generator | GPT-4o-mini | Content creation, audience targeting | - |
| Legal Drafting | GPT-4o-mini | Contract templates, compliance | DocuSign |
| Data Analytics | GPT-4o-mini | Data insights, trend analysis | - |
| Email Marketing | GPT-4o-mini | Campaign creation, A/B testing | - |
| Document Summarization | GPT-4o-mini | Document processing, key extraction | - |
| Customer Support | GPT-4o-mini | Automated responses, FAQ creation | - |
| Sales Analytics | GPT-4o-mini | Performance tracking, forecasting | - |
| Content Creation | GPT-4o-mini | SEO content, brand consistency | - |
| Inventory Tracker | GPT-4o-mini | Demand prediction, alerts | Twilio SMS |
| Logistics Optimizer | GPT-4o-mini | Route planning, optimization | Google Maps |

## 🛡 Security

- **Row Level Security (RLS)** on all database tables
- **User authentication** with Supabase Auth
- **API key protection** via environment variables
- **CORS configuration** for secure cross-origin requests
- **Webhook signature verification** for Stripe payments

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License.

## 🆘 Support

For support and questions:
- Create an issue in this repository
- Check the documentation
- Review the troubleshooting guide in `LOCAL_TESTING_GUIDE.md`

## 🎉 Acknowledgments

- Built with Next.js and Supabase
- AI capabilities powered by OpenAI GPT-4o-mini and Google Gemini
- Payments processed by Stripe
- Real-time communications via Twilio
- Location services by Google Maps
- Document management by DocuSign

---

**Built with ❤️ for entrepreneurs and businesses worldwide**
