# Local Testing Troubleshooting Guide

## Common Issues & Solutions

### 1. Environment Variables
- Ensure `.env.local` file exists with correct Supabase URL
- Check that Supabase anon key matches the one in Supabase dashboard

### 2. Supabase Connection Issues
- Verify internet connection
- Check if Supabase project is active
- Test edge functions directly in Supabase dashboard

### 3. Edge Function Errors
Common errors and fixes:

#### "allItems.filter is not a function"
- **Status**: ✅ Fixed in version 3
- **Test**: Verify inventory tracker shows analytics without errors

#### "BOOT_ERROR - Function failed to start"
- **Status**: ✅ Fixed in version 3  
- **Test**: Verify logistics optimizer loads properly

#### "Invalid API Key" errors
- **Cause**: Missing API keys in Supabase environment
- **Solution**: Add required keys to Supabase edge function environment

### 4. Frontend Build Issues
```bash
# Clear Next.js cache
rm -rf .next

# Reinstall dependencies
rm -rf node_modules
pnpm install

# Rebuild
pnpm build
```

### 5. Database Connection Issues
- Ensure RLS policies allow public access for testing
- Check that all required tables exist:
  - `ai_queries` (8 generic tools)
  - `inventory_items` (inventory tracker)
  - `routes`, `drivers`, `deliveries` (logistics optimizer)

## Testing Checklist

### ✅ Basic Functionality
- [ ] Homepage loads at localhost:3000
- [ ] Dashboard accessible at localhost:3000/dashboard
- [ ] All 10 tools listed in grid layout
- [ ] Tool cards display correctly with icons and descriptions

### ✅ Generic AI Tools (8 tools)
- [ ] Marketing Content Generator - Returns marketing copy
- [ ] Legal Document Drafting - Returns legal suggestions
- [ ] Data Analytics - Returns data insights
- [ ] Email Marketing - Returns email templates
- [ ] Document Summarization - Returns document summaries
- [ ] Customer Support Assistant - Returns support responses
- [ ] Sales Analytics - Returns sales insights
- [ ] Content Creation - Returns content suggestions

### ✅ Specialized Tools (2 tools)
- [ ] Inventory Tracker - Shows stock analytics and AI predictions
- [ ] Logistics Optimizer - Shows route planning and delivery tracking

### ✅ Error Handling
- [ ] Test tools without internet - should show proper error messages
- [ ] Test with invalid inputs - should show validation errors
- [ ] Test edge function timeouts - should show timeout messages

## Performance Expectations

### Response Times
- Generic tools: 2-5 seconds
- Inventory analytics: 3-7 seconds  
- Route optimization: 5-10 seconds
- Dashboard load: <2 seconds

### Browser Console
- No JavaScript errors for successful operations
- CORS errors are normal for edge function calls
- Red errors indicate actual issues to investigate

## Next Steps After Testing

Once local testing is complete:
1. **Push to GitHub** (Task 18)
2. **Deploy to Vercel** (Task 19)
3. **Deploy to Railway** (Task 20)
4. **Configure Stripe** (Task 21)
5. **Production Testing** (Task 22)
6. **Launch Platform** (Task 23)
