#!/bin/bash

# AI Solutions Hub - GitHub Push Script
# Task 18: Complete GitHub Repository Push

echo "🚀 Pushing AI Solutions Hub to GitHub..."
echo "Repository: https://github.com/zgdsait1/Database.git"
echo ""

# Check if we're in the right directory
if [ ! -f "package.json" ]; then
    echo "❌ Error: package.json not found. Please run this script from the ai-solutions-nextjs directory."
    exit 1
fi

# Check Git status
echo "📋 Checking Git status..."
git status

# Add all changes
echo ""
echo "📦 Adding all files to Git..."
git add .

# Commit with comprehensive message
echo ""
echo "💾 Committing changes..."
git commit -m "Complete AI Solutions Hub platform with 10 AI tools

Features added:
✅ AI Smart Inventory Tracker with demand prediction and SMS alerts
✅ AI Logistics & Route Optimizer with route planning and delivery tracking
✅ 8 original generic AI tools (Marketing, Legal, Data, Email, etc.)
✅ Comprehensive README with setup and deployment instructions
✅ Local testing guide and troubleshooting documentation
✅ Complete Supabase edge functions (10 deployed and tested)
✅ Database schema with all required tables and RLS policies
✅ Production-ready for Vercel and Railway deployment

Tech Stack: Next.js 14, TypeScript, Supabase, OpenAI GPT-4o-mini, Stripe, Twilio, Google Maps"

# Push to GitHub
echo ""
echo "🌐 Pushing to GitHub..."
echo "Note: You may need to authenticate with your GitHub credentials"
echo ""

# Configure remote if needed (uncomment and modify if remote is different)
# git remote set-url origin https://github.com/zgdsait1/Database.git

# Push to main branch
git push origin master

echo ""
echo "✅ GitHub push completed!"
echo "Repository URL: https://github.com/zgdsait1/Database"
echo ""
echo "Next steps:"
echo "1. Task 19: Deploy frontend to Vercel"
echo "2. Task 20: Deploy backend to Railway" 
echo "3. Task 21: Configure Stripe webhooks"
echo "4. Task 22: Perform comprehensive testing"
echo "5. Task 23: Launch production platform"
